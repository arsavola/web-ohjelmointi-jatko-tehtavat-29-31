Tehtävät 29 ja 30
server.js ja client.js toimivat yhdessä, käyttävävät kontrollereita customerController.js ja customerTypeController.js 

Tehtävä 31
server2.js ja client2.js toimivat yhdessä, käyttävävät kontrollereita productController.js ja productTypeController.js 